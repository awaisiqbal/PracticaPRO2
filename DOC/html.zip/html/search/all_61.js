var searchData=
[
  ['add_5ftag',['add_tag',['../class_tags.html#ab4220617f466486577ab9699c0b2d8c7',1,'Tags']]],
  ['agenda',['Agenda',['../class_agenda.html',1,'Agenda'],['../class_agenda.html#a6685054d2b4ccbf2a4ef2ac5e3746bc3',1,'Agenda::Agenda()']]],
  ['agenda_2ehh',['agenda.hh',['../agenda_8hh.html',1,'']]],
  ['anadir_5ftag',['anadir_tag',['../class_tarea.html#ad2a354a636f53e862841f2407acedc72',1,'Tarea']]],
  ['anadir_5ftarea',['anadir_tarea',['../class_agenda.html#aeba776d0394a5cc0da53e7955d713133',1,'Agenda']]]
];
