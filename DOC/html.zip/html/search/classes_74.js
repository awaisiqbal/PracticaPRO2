var searchData=
[
  ['tags',['Tags',['../class_tags.html',1,'']]],
  ['tarea',['Tarea',['../class_tarea.html',1,'']]],
  ['token',['Token',['../class_token.html',1,'']]]
];
