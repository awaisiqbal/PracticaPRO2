var searchData=
[
  ['operator_3c',['operator&lt;',['../class_reloj.html#a912ed4e4d552e7289e3711b6a22a35cb',1,'Reloj']]],
  ['operator_3c_3d',['operator&lt;=',['../class_reloj.html#a61b3c87188b6fc6c3ff7953a633057f9',1,'Reloj']]],
  ['operator_3d_3d',['operator==',['../class_reloj.html#af5567b0ddc4f1fa7cf857a2d56314880',1,'Reloj']]]
];
