var searchData=
[
  ['llegir',['llegir',['../class_comanda.html#af2dbc8ccdbb94bed6ea26155edc71b57',1,'Comanda']]]
];
