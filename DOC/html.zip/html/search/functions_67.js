var searchData=
[
  ['get_5ftags',['get_tags',['../class_tags.html#a811129b11acf0ae9c6f224a386075e46',1,'Tags::get_tags()'],['../class_tarea.html#a36fa738d7b7b34992e723c69a7c67065',1,'Tarea::get_tags()']]],
  ['get_5ftitulo',['get_titulo',['../class_tarea.html#a101c30f2185d0e69b7e3188fad33041f',1,'Tarea']]]
];
