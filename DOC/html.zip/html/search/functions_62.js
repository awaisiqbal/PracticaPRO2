var searchData=
[
  ['borrar_5ftag',['borrar_tag',['../class_tags.html#a7a2f42e0533c7ef830fba59a62939a3d',1,'Tags::borrar_tag()'],['../class_tarea.html#a09c81269d5b51fd3418ab38fbc283625',1,'Tarea::borrar_tag()']]],
  ['borrar_5ftarea',['borrar_tarea',['../class_agenda.html#aee3c8541a89cc0a52ea39efda99e52c8',1,'Agenda']]],
  ['buscar_5ftarea_5fintervalo',['buscar_tarea_intervalo',['../class_agenda.html#a33563a51900832ac1daeeb3813d00fdc',1,'Agenda']]]
];
