var searchData=
[
  ['data',['data',['../class_comanda.html#ab4ce0a50bde32145d11cbaee753526c7',1,'Comanda']]]
];
