var searchData=
[
  ['search_5ftag',['search_tag',['../class_tags.html#aff44c4ae5a949512c893d1fc9ab5312a',1,'Tags']]],
  ['set_5ftags',['set_tags',['../class_tarea.html#a70871ce092aceb665b59f2094520bba4',1,'Tarea']]],
  ['set_5ftitulo',['set_titulo',['../class_tarea.html#aa9371098468f9074182b5df5dc240fc3',1,'Tarea']]]
];
