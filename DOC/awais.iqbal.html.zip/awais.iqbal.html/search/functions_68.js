var searchData=
[
  ['hora',['hora',['../class_comanda.html#ae8bca2ad702d3316dc1c53dcab7cac02',1,'Comanda']]],
  ['hora_5fmenor',['hora_menor',['../class_reloj.html#a0e8980f68986d6083ab974ca3b49c78a',1,'Reloj']]]
];
