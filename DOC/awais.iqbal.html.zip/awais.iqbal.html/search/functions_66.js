var searchData=
[
  ['fecha_5fmenor',['fecha_menor',['../class_reloj.html#a12b0c122a6a97fb1d49beeacf2fb4186',1,'Reloj']]]
];
