var searchData=
[
  ['borar_5ftag',['borar_tag',['../class_tarea.html#a302eed4ef2367fcbc10c9fbc98a291ad',1,'Tarea']]],
  ['borrar_5ftag',['borrar_tag',['../class_tags.html#a6b5bf2e8bb405c6396d947543460710b',1,'Tags']]],
  ['borrar_5ftarea',['borrar_tarea',['../class_agenda.html#af1d7e74d388a0b22c8186b4b329d0bae',1,'Agenda']]],
  ['buscar_5ftarea_5fintervalo',['buscar_tarea_intervalo',['../class_agenda.html#a82ce91d05bf272a3c0ead42fc64e84aa',1,'Agenda']]]
];
