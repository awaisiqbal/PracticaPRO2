var searchData=
[
  ['reloj',['Reloj',['../class_reloj.html',1,'Reloj'],['../class_reloj.html#a0966eaa7e7079419049e683bafa7dbc0',1,'Reloj::Reloj()'],['../class_reloj.html#a86f51a4c60125a60897c180303b4f7cc',1,'Reloj::Reloj(string fechaHora)'],['../class_reloj.html#ad74790adea13c7fec942f4733e7a64ba',1,'Reloj::Reloj(string datetime, string hora)']]],
  ['reloj_2ehh',['reloj.hh',['../reloj_8hh.html',1,'']]]
];
